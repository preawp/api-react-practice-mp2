import { useEffect, useState } from "react";
import styled from 'styled-components';

const Bg = styled.div`
    background-color: #ffffff;
    background-image: radial-gradient(circle, #dadada 1px, transparent 1px);
    background-size: 20px 20px;

`;
const Header = styled.div`

    text-align: center;
    font-family: 'The Nautigal', cursive;
    font-weight: bolder;
    font-size: 600%;
    color: #ffffff;
    background-image: linear-gradient(to right,
    #FAEDCB, #C9E4DE, #C6DEF1, #DBCDF0, #F2C6DC, #F7D9C4);
    margin-bottom: 5%;

`;

const Row = styled.div`
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    justify-content: center;
`;

const hoverColors = [
    '#F28E8E',
    '#8EAAF2',
    '#8EF2B4',
    '#F2E18E',
    '#F28EDF',
];

const Card = styled.div`
    color: #888888;
    font-family: 'Quicksand', sans-serif;
    box-shadow: 0 4px 8px 0 rgba(31, 27, 27, 0.06);
    transition: color 0.3s ease, box-shadow 0.3s ease;
    width: 300px;
    border-radius: 5px;
    padding: 20px;
    background-color: #ffffff;

    &:hover {
        color: ${(props) => props.hoverColor || '#000000'};
    }
`;

const CardContent = styled.div`
  margin: 10px 0;
`;

const CardAuthor = styled.p`
    font-weight: bold;
    margin-bottom: 5px;
`;

const CardDate = styled.p`
    font-size: 0.8em;
    color: #777777;
`;

export default function List() {
    const [quotes, setQuotes] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const addFontLink = (href) => {
            const link = document.createElement('link');
            link.rel = 'stylesheet';
            link.href = href;
            document.head.appendChild(link);
        };
        addFontLink('https://fonts.googleapis.com/css2?family=Dancing+Script:wght@400..700&family=Quicksand:wght@300..700&family=The+Nautigal:wght@400;700&display=swap');

        const preconnectGstatic = document.createElement('link');
        preconnectGstatic.rel = 'preconnect';
        preconnectGstatic.href = 'https://fonts.gstatic.com';
        preconnectGstatic.crossOrigin = 'anonymous';
        document.head.appendChild(preconnectGstatic);
        async function fetchData() {
            try {
                const response = await fetch('https://quotesondesign.com/wp-json/wp/v2/posts/?orderby=rand');
                if (!response.ok) {
                    new Error(`HTTP error! status: ${response.status}`);
                }
                const jsonData = await response.json();
                setQuotes(jsonData);
            } catch (error) {
                console.error("Fetch error:", error);
            } finally {
                setLoading(false);
            }
        }

        fetchData();
    }, []);

    if (loading) {
        return <div>Loading...</div>;
    }

    return (
        <>
            <Bg>
                <Header>Quotes on Design</Header>
                <div>
                    <Row>
                        {quotes.map((quote, index) => (
                            <Card
                                key={quote.id}
                                hoverColor={hoverColors[index % hoverColors.length]}
                            >
                                <CardContent dangerouslySetInnerHTML={{ __html: quote.content.rendered }} />
                                <CardAuthor>{quote.title.rendered}</CardAuthor>
                                <CardDate>{new Date(quote.date).toLocaleDateString()}</CardDate>
                            </Card>
                        ))}
                    </Row>
                </div>
            </Bg> {}
        </>
    );

}