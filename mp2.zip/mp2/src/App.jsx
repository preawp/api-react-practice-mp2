import List from './components/List.jsx';
export default function App() {
    return (
        <>
             <List />
        </>
    );
}
